/* Browser-only cache. This is NOT a Cloudflare Worker or server-side function. */
'use strict';
const PREFIX='995-reborn-'+encodeURIComponent(self.registration.scope)+'-';
const CACHE=PREFIX+'build009-803bc23c5f0ed656';
const SHELL=[
 './index.html','./memorial.css','./memorial.js','./manifest.webmanifest',
 './assets/icon.svg','./assets/icon-192.png','./assets/icon-512.png',
 './assets/vehicles/jetta-mkiv/volkswagen-bora-jetta-mk4-2005.cc-by-4.0.glb',
 './assets/vehicles/jetta-mkiv/CREDITS.md',
 './assets/worlds/north-berwick/world.json',
 './assets/worlds/north-berwick/CREDITS.md',
 './assets/worlds/north-berwick/provenance.json',
 './assets/worlds/north-berwick/facades-atlas.webp',
 './assets/worlds/north-berwick/facades-atlas.json'
];
const scopeURL=new URL(self.registration.scope);
const shellURLs=new Set(SHELL.map(p=>new URL(p,scopeURL).href));
self.addEventListener('install',event=>event.waitUntil((async()=>{
 const cache=await caches.open(CACHE);
 // Never activate a partial update with a missing hero car, hometown world, or facade atlas.
 await cache.addAll(SHELL.map(p=>new Request(new URL(p,scopeURL),{cache:'reload'})));
 await self.skipWaiting();
})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{
 const names=await caches.keys();
 await Promise.all(names.filter(key=>key.startsWith(PREFIX)&&key!==CACHE).map(key=>caches.delete(key)));
 await self.clients.claim();
})()));
self.addEventListener('fetch',event=>{
 const request=event.request,url=new URL(request.url);
 if(request.method!=='GET'||url.origin!==scopeURL.origin||!url.pathname.startsWith(scopeURL.pathname))return;
 const isEntry=url.pathname===scopeURL.pathname||url.pathname===scopeURL.pathname+'index.html';
 if(request.mode==='navigate'&&isEntry){
  event.respondWith((async()=>{
   const cache=await caches.open(CACHE);
   try{
    const response=await fetch(request);
    if(response.ok){await cache.put(new URL('./index.html',scopeURL),response.clone());return response;}
    if(response.status<500)return response;
    return await cache.match(new URL('./index.html',scopeURL))||response;
   }catch(error){const cached=await cache.match(new URL('./index.html',scopeURL));if(cached)return cached;throw error;}
  })());return;
 }
 url.search='';url.hash='';
 if(!shellURLs.has(url.href))return;
 event.respondWith((async()=>{
  const cache=await caches.open(CACHE),cached=await cache.match(url.href);
  if(cached)return cached;
  const response=await fetch(request);
  if(response.ok&&response.type!=='opaque')await cache.put(url.href,response.clone());
  return response;
 })());
});
